#ifndef _JZAJ_H
#include<reg52.h>
#include"public.h"
void keyscan(u8 *p,u8 *q);
#endif